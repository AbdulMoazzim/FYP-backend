# AGILIRO — Scrum Master Agent

## Status
- **Day 1** — Design doc (inputs, `AgentResult` output shape, workflow, tech decisions)
- **Day 2** — Scaffolding: FastAPI app, `ProjectContext`/`AgentResult` Pydantic models, SQLAlchemy `agent_results` table, mock context fixture
- **Day 3** — Blocker & risk detection: LangGraph node + prompt + 7 passing unit tests
- Day 4+ — sprint planning/monitoring, evidence+persistence wiring, integration (not started)

## Setup
```bash
pip install -r requirements.txt
python -m pytest tests/ -v          # run unit tests
uvicorn app.main:app --reload       # run the API (http://localhost:8000/docs)
```

## Try it
```bash
curl -X POST http://localhost:8000/scrum-master/analyze \
  -H "Content-Type: application/json" \
  -d @mock_data/project_context_sample.json
```
Returns a list of `AgentResult`s for whatever blockers/risks are in the sample data.

## Structure
```
app/
  models/           # ProjectContext + AgentResult contracts (shared shapes)
  db/                # SQLAlchemy models + session (SQLite locally, swap DATABASE_URL for Postgres)
  agents/scrum_master/
    llm.py           # LLMClient interface — MockLLMClient (used now) + GeminiLLMClient (stub, Day 4+)
    prompts.py        # Prompt template for the real LLM call
    blocker_risk.py   # Day 3 core logic
    graph.py           # LangGraph wiring
  api/routes/         # FastAPI endpoints
mock_data/            # Sample ProjectContext with blocker/risk/healthy scenarios
tests/                # Unit tests (MockLLMClient, deterministic)
```

## Notes for whoever picks this up next
- `MockLLMClient` is keyword-based on purpose — it's a stand-in so the agent
  logic is testable without API keys. Swap it for `GeminiLLMClient` (fill in
  the real call using `prompts.BLOCKER_RISK_PROMPT`) once we have credentials.
- `AgentResult` fields in `app/models/agent_result.py` are a Day-1 working
  assumption — confirm against the group's actual shared spec before other
  agents start depending on this shape.
- Persistence (writing `AgentResult`s to `agent_results` via `AgentResultORM`)
  is Day 5 scope — the API currently returns results directly without saving them.
