"""
Day 3 deliverable: blocker & risk identification.

detect_blockers_and_risks() scans a ProjectContext's backlog items and
events, asks the LLM client to judge each one, and returns AgentResults
— every one carrying evidence back to its source (backlog item id or
event source_ref), per the evidence-grounding requirement in the Day 1
doc.
"""
from typing import List

from app.agents.scrum_master.llm import LLMClient
from app.models.agent_result import AgentResult, Evidence, RecommendationType
from app.models.project_context import BacklogItem, Event, ProjectContext


def _source_ref_for_item(item: BacklogItem) -> str:
    return item.source_refs[0] if item.source_refs else f"backlog_item:{item.item_id}"


def detect_blockers_and_risks(context: ProjectContext, llm: LLMClient) -> List[AgentResult]:
    results: List[AgentResult] = []

    for item in context.backlog_items:
        snippet = f"Backlog item '{item.title}' (status={item.status.value}, priority={item.priority})"
        verdict = llm.classify_blocker_or_risk(item, snippet)
        if not verdict["is_match"]:
            continue

        rec_type = RecommendationType.BLOCKER if verdict["type"] == "blocker" else RecommendationType.RISK
        results.append(
            AgentResult(
                recommendation_type=rec_type,
                summary=f"{'Blocker' if rec_type == RecommendationType.BLOCKER else 'Risk'} detected on '{item.title}'",
                reasoning=verdict["reasoning"],
                evidence=[Evidence(source_ref=_source_ref_for_item(item), excerpt=snippet)],
                confidence=verdict["confidence"],
                affected_items=[item.item_id],
            )
        )

    for event in context.events:
        verdict = llm.classify_blocker_or_risk(event, event.raw_text)
        if not verdict["is_match"]:
            continue

        rec_type = RecommendationType.BLOCKER if verdict["type"] == "blocker" else RecommendationType.RISK
        results.append(
            AgentResult(
                recommendation_type=rec_type,
                summary=f"{'Blocker' if rec_type == RecommendationType.BLOCKER else 'Risk'} raised in {event.type.value}",
                reasoning=verdict["reasoning"],
                evidence=[Evidence(source_ref=event.source_ref, excerpt=event.raw_text)],
                confidence=verdict["confidence"],
                affected_items=[context.sprint.sprint_id],
            )
        )

    return results
