"""
LangGraph state graph for the Scrum Master Agent.

Day 3 scope: only the blocker/risk node is wired in. Day 4 adds a
sprint-planning/monitoring node in parallel; Day 5 adds a persist node
after this. Kept intentionally small so each day's work is one clear
diff instead of a rewrite.
"""
from typing import List, TypedDict

from langgraph.graph import END, StateGraph

from app.agents.scrum_master.blocker_risk import detect_blockers_and_risks
from app.agents.scrum_master.llm import LLMClient, MockLLMClient
from app.models.agent_result import AgentResult
from app.models.project_context import ProjectContext


class ScrumMasterState(TypedDict):
    context: ProjectContext
    results: List[AgentResult]


def _blocker_risk_node(state: ScrumMasterState, llm: LLMClient) -> ScrumMasterState:
    new_results = detect_blockers_and_risks(state["context"], llm)
    return {"context": state["context"], "results": state["results"] + new_results}


def build_scrum_master_graph(llm: LLMClient = None):
    llm = llm or MockLLMClient()
    graph = StateGraph(ScrumMasterState)

    graph.add_node("blocker_risk", lambda state: _blocker_risk_node(state, llm))
    # Day 4: graph.add_node("sprint_planning", ...)
    # Day 5: graph.add_node("persist", ...)

    graph.set_entry_point("blocker_risk")
    graph.add_edge("blocker_risk", END)

    return graph.compile()


def run_scrum_master_agent(context: ProjectContext, llm: LLMClient = None) -> List[AgentResult]:
    app = build_scrum_master_graph(llm)
    final_state: ScrumMasterState = app.invoke({"context": context, "results": []})
    return final_state["results"]
