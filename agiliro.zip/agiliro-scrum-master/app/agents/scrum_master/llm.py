"""
LLM client abstraction for the Scrum Master Agent.

Two implementations:
- MockLLMClient: deterministic, rule-based. No network calls. Used in
  unit tests and local dev so the agent logic is testable without API
  keys, and so tests aren't flaky against a real model's output.
- GeminiLLMClient: thin wrapper intended for the real Gemini/Groq call
  via LangChain (per the proposal's tech stack). Not exercised in tests
  here — wire up the actual API key and langchain-google-genai /
  langchain-groq client when we have credentials.

`blocker_risk.py` depends only on the `LLMClient` interface, so swapping
Mock -> Gemini later is a one-line change at the call site.
"""
from abc import ABC, abstractmethod
from typing import List

from app.models.project_context import BacklogItem, BacklogStatus, Event

RISK_KEYWORDS = ("risk", "concern", "delay", "at risk", "behind schedule", "won't make it", "wont make it")
BLOCKER_KEYWORDS = ("blocked", "blocker", "waiting on", "can't proceed", "cant proceed", "stuck")


class LLMClient(ABC):
    @abstractmethod
    def classify_blocker_or_risk(self, item_or_event, context_snippet: str) -> dict:
        """Returns {"is_match": bool, "type": "blocker"|"risk", "reasoning": str, "confidence": float}"""
        raise NotImplementedError


class MockLLMClient(LLMClient):
    """Deterministic keyword-based stand-in for the real LLM call.

    This intentionally mirrors the *kind* of judgment we'd ask the real
    model for (read backlog item / event text, decide if it signals a
    blocker or risk, explain why) without needing network access.
    """

    def classify_blocker_or_risk(self, item_or_event, context_snippet: str) -> dict:
        text = context_snippet.lower()

        if isinstance(item_or_event, BacklogItem) and item_or_event.status == BacklogStatus.BLOCKED:
            return {
                "is_match": True,
                "type": "blocker",
                "reasoning": f"Backlog item '{item_or_event.title}' is explicitly marked as blocked.",
                "confidence": 0.95,
            }

        if any(kw in text for kw in BLOCKER_KEYWORDS):
            return {
                "is_match": True,
                "type": "blocker",
                "reasoning": "Source text contains explicit blocker language.",
                "confidence": 0.75,
            }

        if any(kw in text for kw in RISK_KEYWORDS):
            return {
                "is_match": True,
                "type": "risk",
                "reasoning": "Source text contains language indicating schedule/delivery risk.",
                "confidence": 0.65,
            }

        return {"is_match": False, "type": None, "reasoning": "", "confidence": 0.0}


class GeminiLLMClient(LLMClient):
    """Real provider client — not used in tests. Requires GOOGLE_API_KEY
    and `langchain-google-genai` installed once we're ready to call out."""

    def __init__(self, model: str = "gemini-1.5-flash"):
        self.model = model

    def classify_blocker_or_risk(self, item_or_event, context_snippet: str) -> dict:
        raise NotImplementedError(
            "Wire this up once we have API credentials — see prompts.py "
            "for the prompt template to send via LangChain."
        )
