from fastapi import APIRouter

from app.agents.scrum_master.graph import run_scrum_master_agent
from app.models.agent_result import AgentResult
from app.models.project_context import ProjectContext

router = APIRouter()


@router.post("/analyze", response_model=list[AgentResult])
def analyze(context: ProjectContext):
    """Run the Scrum Master Agent (currently: blocker & risk detection,
    Day 3 scope) against a ProjectContext and return AgentResults.
    Persistence to Postgres lands Day 5 — for now results are returned
    directly, not stored."""
    return run_scrum_master_agent(context)
