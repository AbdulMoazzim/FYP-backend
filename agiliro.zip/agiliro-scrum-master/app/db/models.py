import uuid
from datetime import datetime

from sqlalchemy import Column, DateTime, Float, String
from sqlalchemy.types import JSON

from app.db.database import Base


class AgentResultORM(Base):
    __tablename__ = "agent_results"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent = Column(String, nullable=False, default="scrum_master")
    recommendation_type = Column(String, nullable=False)
    summary = Column(String, nullable=False)
    reasoning = Column(String, nullable=False)
    evidence = Column(JSON, nullable=False, default=list)
    confidence = Column(Float, nullable=False, default=0.5)
    affected_items = Column(JSON, nullable=False, default=list)
    status = Column(String, nullable=False, default="pending_review")
    project_id = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
