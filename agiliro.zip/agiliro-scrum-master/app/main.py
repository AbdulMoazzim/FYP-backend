from fastapi import FastAPI

from app.api.routes import scrum_master
from app.db.database import init_db

app = FastAPI(title="AGILIRO — Scrum Master Agent")

app.include_router(scrum_master.router, prefix="/scrum-master", tags=["scrum-master"])


@app.on_event("startup")
def on_startup():
    init_db()


@app.get("/health")
def health():
    return {"status": "ok"}
