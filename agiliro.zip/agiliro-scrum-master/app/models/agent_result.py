"""
AgentResult — the shared output contract every agent (Product Owner, Scrum
Master, Knowledge Agent) must emit.

NOTE: this is the Day-1 working assumption for the group's shared spec.
Swap the fields below for the real spec once confirmed — the rest of the
Scrum Master Agent code only depends on this module, so that's the only
place a change should be needed.
"""
from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field


class RecommendationType(str, Enum):
    BLOCKER = "blocker"
    RISK = "risk"
    SPRINT_PLANNING = "sprint_planning"
    SPRINT_MONITORING = "sprint_monitoring"


class ReviewStatus(str, Enum):
    PENDING_REVIEW = "pending_review"
    APPROVED = "approved"
    REJECTED = "rejected"


class Evidence(BaseModel):
    source_ref: str
    excerpt: str


class AgentResult(BaseModel):
    agent: str = "scrum_master"
    recommendation_type: RecommendationType
    summary: str
    reasoning: str
    evidence: List[Evidence] = Field(default_factory=list)
    confidence: float = Field(ge=0.0, le=1.0, default=0.5)
    affected_items: List[str] = Field(default_factory=list)
    status: ReviewStatus = ReviewStatus.PENDING_REVIEW

    def has_evidence(self) -> bool:
        """Enforces the proposal's evidence-grounding requirement — a
        result with no citation should never reach the Review Dashboard."""
        return len(self.evidence) > 0
