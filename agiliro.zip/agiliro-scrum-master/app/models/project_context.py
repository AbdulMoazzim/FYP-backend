"""
ProjectContext models — the input contract for all three AGILIRO agents.

This mirrors the mock schema agreed in the Day 1 doc. Once the Knowledge
Agent's retrieval pipeline is live, these same shapes get populated from
the vector store instead of a JSON fixture — the Scrum Master Agent code
shouldn't need to change.
"""
from datetime import datetime
from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field


class BacklogStatus(str, Enum):
    TODO = "todo"
    IN_PROGRESS = "in_progress"
    BLOCKED = "blocked"
    DONE = "done"


class EventType(str, Enum):
    MEETING_SUMMARY = "meeting_summary"
    STATUS_UPDATE = "status_update"
    CHAT_UPDATE = "chat_update"
    MANUAL_EDIT = "manual_edit"


class Sprint(BaseModel):
    sprint_id: str
    start_date: datetime
    end_date: datetime
    goal: str


class BacklogItem(BaseModel):
    item_id: str
    title: str
    status: BacklogStatus
    assignee: Optional[str] = None
    priority: Optional[str] = None
    last_updated: datetime
    source_refs: List[str] = Field(default_factory=list)


class Event(BaseModel):
    event_id: str
    type: EventType
    timestamp: datetime
    raw_text: str
    source_ref: str


class ProjectContext(BaseModel):
    project_id: str
    sprint: Sprint
    backlog_items: List[BacklogItem] = Field(default_factory=list)
    events: List[Event] = Field(default_factory=list)
