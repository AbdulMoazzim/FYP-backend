import json
from datetime import datetime
from pathlib import Path

import pytest

from app.agents.scrum_master.blocker_risk import detect_blockers_and_risks
from app.agents.scrum_master.graph import run_scrum_master_agent
from app.agents.scrum_master.llm import MockLLMClient
from app.models.agent_result import RecommendationType
from app.models.project_context import (
    BacklogItem, BacklogStatus, Event, EventType, ProjectContext, Sprint,
)

FIXTURE_PATH = Path(__file__).parent.parent / "mock_data" / "project_context_sample.json"


@pytest.fixture
def sample_context() -> ProjectContext:
    data = json.loads(FIXTURE_PATH.read_text())
    return ProjectContext(**data)


@pytest.fixture
def llm():
    return MockLLMClient()


# --- Hand-written scenarios -------------------------------------------------

def test_blocked_backlog_item_is_flagged_as_blocker(sample_context, llm):
    results = detect_blockers_and_risks(sample_context, llm)
    blocker_hits = [r for r in results if r.recommendation_type == RecommendationType.BLOCKER
                    and "BL-101" in r.affected_items]
    assert len(blocker_hits) == 1
    assert blocker_hits[0].has_evidence()
    assert blocker_hits[0].evidence[0].source_ref == "jira:BL-101"


def test_event_with_blocker_language_is_flagged(sample_context, llm):
    results = detect_blockers_and_risks(sample_context, llm)
    matches = [r for r in results if r.recommendation_type == RecommendationType.BLOCKER
               and r.evidence[0].source_ref == "slack:EVT-1"]
    assert len(matches) == 1
    assert "waiting on" in matches[0].evidence[0].excerpt.lower()


def test_event_with_risk_language_is_flagged(sample_context, llm):
    results = detect_blockers_and_risks(sample_context, llm)
    matches = [r for r in results if r.recommendation_type == RecommendationType.RISK
               and r.evidence[0].source_ref == "meeting:standup-0918"]
    assert len(matches) == 1
    assert matches[0].confidence > 0


def test_healthy_item_and_event_produce_no_false_positive(sample_context, llm):
    results = detect_blockers_and_risks(sample_context, llm)
    # BL-102 (in_progress, no risk language) and BL-103/EVT-3 (done/positive update)
    # should never show up as a blocker or risk.
    flagged_ids = {i for r in results for i in r.affected_items}
    flagged_refs = {r.evidence[0].source_ref for r in results if r.evidence}
    assert "BL-102" not in flagged_ids
    assert "BL-103" not in flagged_ids
    assert "slack:EVT-3" not in flagged_refs


def test_every_result_carries_evidence(sample_context, llm):
    results = detect_blockers_and_risks(sample_context, llm)
    assert len(results) > 0
    assert all(r.has_evidence() for r in results)


def test_no_blockers_or_risks_on_an_empty_context(llm):
    empty_context = ProjectContext(
        project_id="empty-proj",
        sprint=Sprint(
            sprint_id="sprint-0",
            start_date=datetime(2026, 1, 1),
            end_date=datetime(2026, 1, 14),
            goal="n/a",
        ),
        backlog_items=[],
        events=[],
    )
    assert detect_blockers_and_risks(empty_context, llm) == []


def test_end_to_end_via_langgraph_matches_direct_call(sample_context, llm):
    """Sanity check that the LangGraph wrapper doesn't change the outcome
    vs calling detect_blockers_and_risks directly."""
    direct = detect_blockers_and_risks(sample_context, llm)
    via_graph = run_scrum_master_agent(sample_context, llm)
    assert len(direct) == len(via_graph)
    assert {r.summary for r in direct} == {r.summary for r in via_graph}
