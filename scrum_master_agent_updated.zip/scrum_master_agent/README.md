# Scrum Master Agent — AGILIRO

One of three agents in AGILIRO (with Product Owner Agent & Knowledge Agent). Takes project/sprint/backlog data and produces evidence-linked recommendations for blockers, risks, sprint planning, and sprint monitoring. Every recommendation cites its source and requires human approval before affecting any artifact.

## Status (Day 5)

Everything below is real, tested code — not just described:

- ✅ ProjectContext confirmed against Arfa's (PO Agent) actual schema — validated as-is, with optional sprint/backlog-status fields layered on top
- ✅ `api/`, `core/`, `db/`, `agents/scrum_master/` folder structure
- ✅ `agent_results` table — real Alembic migration, applied and verified (SQLite for local dev, Postgres-ready via `DATABASE_URL`)
- ✅ Deterministic blocker/risk/sprint-planning/sprint-monitoring detection — rule-based, evidence-cited, no LLM credentials required
- ✅ Detection wrapped as a LangGraph node — direct call and graph call verified to produce identical output
- ✅ `POST /scrum-master/analyze` — runs detection and persists every result to the DB
- ⏳ Real LLM call (swap-in for the deterministic detector) — not yet started

**Known gap:** Arfa's ProjectContext has no sprint/backlog-status/event data — that's layered on as optional fields for now. Needs a team decision: added upstream, or merged from a second source.

## Setup

```bash
pip install -r requirements.txt
alembic upgrade head           # creates agent_results (SQLite by default)
python smoke_test.py           # full end-to-end check, no LLM needed
uvicorn app.main:app --reload
```

## Try it

```bash
curl -X POST "http://127.0.0.1:8000/scrum-master/analyze?project_id=proj-agiliro-002" \
  -H "Content-Type: application/json" \
  -d @data/sample_troubled.json
```

Returns real findings (blockers, risks, sprint pace warnings), each with cited evidence, and writes them to `agent_results`.

## Structure

```
app/
  main.py
  api/scrum_master.py            # /ingest, /context-preview, /analyze
  core/config.py                 # env vars (DATABASE_URL, LLM_PROVIDER)
  db/models.py, session.py       # SQLAlchemy: AgentResultORM
  schemas.py, ingestion.py, context_builder.py
  agents/scrum_master/
    schemas.py, prompts.py       # re-export canonical schemas/prompt
    detection.py                 # rule-based blocker/risk/planning/monitoring logic
    agent.py                     # LangGraph node wrapping detection.py
alembic/                         # migrations
data/
  project_context_from_arfa.json # her payload, unmodified
  sample_healthy.json, sample_troubled.json
smoke_test.py
```

## Stack

Python · FastAPI · PostgreSQL (SQLAlchemy + Alembic) · LangGraph · Groq (planned)

## Contributors

Abdul Moazzim · Taha Naqvi · Arfa Tariq (PO Agent — ProjectContext schema)
