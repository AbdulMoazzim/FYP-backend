"""
Wraps detect_blockers_and_risks as a LangGraph node inside the agent's
state graph, so calling it directly (run()) and calling it through the
graph (run_via_graph()) give identical output — this is what lets
sprint-planning/monitoring logic be composed as additional nodes later
without touching this one.
"""

from typing import List, TypedDict

from langgraph.graph import END, StateGraph

from ...schemas import AgentResult, ProjectData
from .detection import detect_blockers_and_risks


class AgentState(TypedDict):
    project_id: str
    data: ProjectData
    results: List[AgentResult]


def _detect_node(state: AgentState) -> AgentState:
    results = detect_blockers_and_risks(state["project_id"], state["data"])
    return {**state, "results": results}


def _build_graph():
    graph = StateGraph(AgentState)
    graph.add_node("detect", _detect_node)
    graph.set_entry_point("detect")
    graph.add_edge("detect", END)
    return graph.compile()


_compiled_graph = _build_graph()


def run(project_id: str, data: ProjectData) -> List[AgentResult]:
    """Direct function call path — used by the API route today."""
    return detect_blockers_and_risks(project_id, data)


def run_via_graph(project_id: str, data: ProjectData) -> List[AgentResult]:
    """Same logic via the LangGraph state graph — proves the two paths agree."""
    final_state = _compiled_graph.invoke(
        {"project_id": project_id, "data": data, "results": []}
    )
    return final_state["results"]
