"""
Scrum Master Agent API routes.
"""

from typing import Optional

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import PlainTextResponse

from ..agents.scrum_master.agent import run as agent_run
from ..context_builder import build_context_block
from ..db.models import AgentResultORM
from ..db.session import SessionLocal
from ..ingestion import IngestionError, ingest_project_context

router = APIRouter()


@router.post("/scrum-master/ingest")
def ingest(raw: dict, project_id: Optional[str] = Query(default=None)):
    """Validate and normalize one project's data out of the raw payload."""
    try:
        pid, data = ingest_project_context(raw, project_id)
    except IngestionError as exc:
        raise HTTPException(status_code=422, detail=exc.details) from exc
    return {"project_id": pid, **data.model_dump()}


@router.post("/scrum-master/context-preview", response_class=PlainTextResponse)
def context_preview(raw: dict, project_id: Optional[str] = Query(default=None)):
    """Preview the exact text block that would be sent to the LLM."""
    try:
        pid, data = ingest_project_context(raw, project_id)
    except IngestionError as exc:
        raise HTTPException(status_code=422, detail=exc.details) from exc
    return build_context_block(pid, data)


@router.post("/scrum-master/analyze")
def analyze(raw: dict, project_id: Optional[str] = Query(default=None)):
    """
    Validate the ProjectContext, run blocker/risk detection, persist
    every finding to agent_results, and return the results.
    """
    try:
        pid, data = ingest_project_context(raw, project_id)
    except IngestionError as exc:
        raise HTTPException(status_code=422, detail=exc.details) from exc

    results = agent_run(pid, data)

    db = SessionLocal()
    try:
        for r in results:
            db.add(AgentResultORM(
                agent=r.agent,
                project_id=pid,
                recommendation_type=r.recommendation_type.value,
                summary=r.summary,
                reasoning=r.reasoning,
                evidence=[e.model_dump() for e in r.evidence],
                confidence=r.confidence,
                affected_items=r.affected_items,
                status=r.status.value,
            ))
        db.commit()
    finally:
        db.close()

    return [r.model_dump() for r in results]
