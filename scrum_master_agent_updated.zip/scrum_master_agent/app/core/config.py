"""
Core config — environment-driven settings.

DATABASE_URL defaults to a local SQLite file for dev/testing without a
Postgres server running. In deployment this is set to the real Postgres
connection string; no application code changes, only the env var.
"""

import os

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./scrum_master.db")
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
LLM_PROVIDER = os.getenv("LLM_PROVIDER", "groq")
