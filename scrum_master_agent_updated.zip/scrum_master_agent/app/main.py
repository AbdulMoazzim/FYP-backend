"""
FastAPI app for the Scrum Master Agent.
"""

from fastapi import FastAPI

from .api.scrum_master import router as scrum_master_router

app = FastAPI(title="Scrum Master Agent", version="0.5.0-day5")

app.include_router(scrum_master_router)


@app.get("/health")
def health():
    return {"status": "ok"}
