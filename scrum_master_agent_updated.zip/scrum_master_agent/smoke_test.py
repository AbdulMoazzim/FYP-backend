"""
End-to-end smoke test, no external LLM credentials required.

Covers:
1. Ingestion against Arfa's real payload + two enriched samples
2. Context/prompt builder
3. AgentResult evidence-enforcement guard
4. Blocker/risk detection logic (direct call and via LangGraph node —
   must agree)
5. The /scrum-master/analyze API route, including real DB persistence
"""

import json
from pathlib import Path

from pydantic import ValidationError

from app.agents.scrum_master.agent import run, run_via_graph
from app.context_builder import build_context_block, build_messages
from app.db.models import AgentResultORM
from app.db.session import Base, SessionLocal, engine
from app.ingestion import ingest_project_context
from app.schemas import AgentResult

DATA_DIR = Path(__file__).parent / "data"

# Make sure tables exist for this run (normally handled by `alembic upgrade head`)
Base.metadata.create_all(engine)

print("=" * 70)
print("1. Ingestion + context builder")
print("=" * 70)
for name in ["project_context_from_arfa.json", "sample_healthy.json", "sample_troubled.json"]:
    raw = json.loads((DATA_DIR / name).read_text())
    project_id, data = ingest_project_context(raw)
    block = build_context_block(project_id, data)
    messages = build_messages(project_id, data)
    assert messages[0]["role"] == "system"
    print(f"{name}: OK — project={project_id}, "
          f"has_sprint={data.sprint is not None}, "
          f"{len(data.backlog_items)} backlog items, {len(data.events)} events")

print("\n" + "=" * 70)
print("2. AgentResult evidence-enforcement guard")
print("=" * 70)
try:
    AgentResult(
        recommendation_type="blocker", summary="x", reasoning="x",
        evidence=[], confidence=0.9, affected_items=[],
    )
    print("FAIL: accepted empty evidence")
except ValidationError:
    print("PASS: empty evidence[] correctly rejected")

print("\n" + "=" * 70)
print("3. Blocker/risk detection — direct call vs LangGraph node")
print("=" * 70)
raw = json.loads((DATA_DIR / "sample_troubled.json").read_text())
pid, data = ingest_project_context(raw)
direct = run(pid, data)
via_graph = run_via_graph(pid, data)
assert [r.summary for r in direct] == [r.summary for r in via_graph]
print(f"PASS: {len(direct)} findings, direct call and LangGraph node agree")
for r in direct:
    assert len(r.evidence) > 0, "every finding must carry evidence"
print("PASS: every finding carries non-empty evidence")

raw_healthy = json.loads((DATA_DIR / "sample_healthy.json").read_text())
pid_h, data_h = ingest_project_context(raw_healthy)
healthy_results = run(pid_h, data_h)
blockers = [r for r in healthy_results if r.recommendation_type.value == "blocker"]
assert len(blockers) == 0, "healthy sample should not produce blockers"
print(f"PASS: healthy sample produced {len(healthy_results)} findings, 0 of them blockers")

print("\n" + "=" * 70)
print("4. /scrum-master/analyze — API + DB persistence")
print("=" * 70)
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)
r = client.get("/health")
assert r.status_code == 200

r = client.post(
    "/scrum-master/analyze", json=raw, params={"project_id": "proj-agiliro-002"}
)
assert r.status_code == 200
returned = r.json()
print(f"PASS: /analyze returned {len(returned)} results (HTTP {r.status_code})")

db = SessionLocal()
try:
    count = db.query(AgentResultORM).filter_by(project_id="proj-agiliro-002").count()
finally:
    db.close()
assert count >= len(returned), "results should be persisted to agent_results"
print(f"PASS: {count} rows found in agent_results for proj-agiliro-002")

print("\nAll smoke tests passed.")
